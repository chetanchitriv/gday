export const environment = {
  production: true,
  apiEndPoint: '',
};
