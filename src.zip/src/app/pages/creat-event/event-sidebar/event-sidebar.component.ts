import { Component, OnInit } from '@angular/core';
import { NgxUiLoaderService } from 'ngx-ui-loader';
import { EventService } from '../../shared/services/event/event.service';
@Component({
  selector: 'app-event-sidebar',
  templateUrl: './event-sidebar.component.html',
  styleUrls: ['./event-sidebar.component.scss']
})
export class EventSidebarComponent implements OnInit {

  selectedEventType:string="upcomming";
  Events:any=[]
  
  
    constructor(private eventService:EventService,
      private ngxLoader: NgxUiLoaderService,) { }
  
      ngOnInit(): void {
        this.getUpcomingEventList();
        
       }
  
    async getUpcomingEventList(){
      this.ngxLoader.start();
      const response:any = await this.eventService.getUpcomingEvent();
      if(response.msg=="Success"){
        this.Events=response.data;
        // this.selectedEventType=this.publicEvents;
        console.log(this.Events)
      }
    }
    async getCurrentEventList(){
      this.ngxLoader.start();
      const response:any = await this.eventService.getCurrentEvent();
      if(response.msg=="Success"){
        this.Events=response.data;
        console.log(this.Events)
      }
    }
  
    async getPastEventList(){
      this.ngxLoader.start();
      const response:any = await this.eventService.getPastEvent();
      if(response.msg=="Success"){
        this.Events=response.data;
        console.log(this.Events)
      }
    }
  

}
