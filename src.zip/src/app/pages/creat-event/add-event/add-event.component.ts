import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { TranslateService } from '@ngx-translate/core';
import { NgxUiLoaderService } from 'ngx-ui-loader';
import { RegexEnum } from '../../global/regex-enum';
import { LOCAL_STORAGE_KEYS } from '../../global/constants';
import { AuthenticationService } from '../../shared/services/auth/auth.service';
import { EventService } from '../../shared/services/event/event.service';
import { FormService } from '../../shared/services/form.service';
import { LocalStorageService } from '../../shared/services/local-storage.service';
import { UtilityService } from '../../shared/services/utility.service';
@Component({
  selector: 'app-add-event',
  templateUrl: './add-event.component.html',
  styleUrls: ['./add-event.component.scss']
})
export class AddEventComponent implements OnInit {

  createEventForm: FormGroup;
  messageList: any = {};

  constructor(
    private eventService: EventService,
    private formBuilder: FormBuilder,
    public translation: TranslateService,
    private formService: FormService,
    private localStorage: LocalStorageService,
    private utilsService: UtilityService,
    private ngxLoader: NgxUiLoaderService,
    private router:Router
  ) { }


  ngOnInit(): void {
    this.intializingCreateEventForm();
    this.intializingMessage();
  }

  intializingCreateEventForm() {
   
    return this.createEventForm = this.formBuilder.group({
      event_name: ['', [Validators.required, Validators.pattern(RegexEnum.name)]],
      start_date: ['', [Validators.required]],
      end_date: ['', [Validators.required]],
      start_time: ['', [Validators.required]],
      end_time: ['', [Validators.required]],
      description: ['', [Validators.required, Validators.pattern(RegexEnum.name)]],
      type: ['', [Validators.required]],
    });
  }

  get createEventFormControls() { return this.createEventForm.controls; }
 

  intializingMessage() {
    
    this.messageList.event_name = {
      pattern: this.translation.instant('Only Character allowed'),
      required: this.translation.instant('ERR_MSG_EVENT_TITLE_REQUIRED'),
    };
    this.messageList.start_date = {
      required: this.translation.instant('Start Date required'),
    };
    this.messageList.end_date = {
      required: this.translation.instant('End Date Required'),
    };

    this.messageList.start_time = {
      required: this.translation.instant('Start Time required'),
    };
    
    this.messageList.end_time = {
      required: this.translation.instant('End Time required'),
    };

    this.messageList.description = {
      pattern: this.translation.instant('Invalid Description'),
      required: this.translation.instant('Description required'),
    };
    this.messageList.type = {
      required: this.translation.instant('Event type required'),
    };

  }
  async onCreateEvent() {
    console.log(this.createEventForm.value)
    this.formService.markFormGroupTouched(this.createEventForm);
    if (this.createEventForm.valid) {
      
      this.ngxLoader.start();
      const sendData = await this.utilsService.cleanObject(this.createEventForm.getRawValue());
     const response: any = await this.eventService.addEvent(sendData);
      if (response.msg == "Success") {
        
        await this.localStorage.setDataInIndexedDB(LOCAL_STORAGE_KEYS.MOBILE, sendData.mobile);
      
        const initialState = {};
    
        //  await this.localStorage.setDataInIndexedDB(LOCAL_STORAGE_KEYS.MOBILE, sendData.mobile);
      }
    }
  }

}
