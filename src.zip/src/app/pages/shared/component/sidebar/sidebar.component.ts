import { Component, OnInit } from '@angular/core';
import { NgxUiLoaderService } from 'ngx-ui-loader';
import { EventService } from '../../services/event/event.service';

@Component({
  selector: 'app-sidebar',
  templateUrl: './sidebar.component.html',
  styleUrls: ['./sidebar.component.scss']
})
export class SidebarComponent implements OnInit {
selectedEventType:String="publicEvents";
// selectedEventType2:String="privateEvents";
// ="publicEvents";

Events:any=[]

// upcomming = [
//   {"name":"Walter Andrews","title":"Live From The Basement","members":5,"date":"10 Aug 2020"},
//   {"name":"Walter Andrews","title":"Live From The Basement","members":5,"date":"10 Aug 2020"},
//   {"name":"Walter Andrews","title":"Live From The Basement","members":5,"date":"10 Aug 2020"}
// ]
  constructor(private eventService:EventService,
    private ngxLoader: NgxUiLoaderService,) { }


  async getPublicEventList(){
    this.ngxLoader.start();
    const response:any = await this.eventService.getPublicEvent();
    if(response.msg=="Success"){
      this.Events=response.data;
      // this.selectedEventType=this.publicEvents;
      console.log(this.Events)
    }
  }
  async getPrivateEventList(){
    this.ngxLoader.start();
    const response:any = await this.eventService.getPrivateEvent();
    if(response.msg=="Success"){
      this.Events=response.data;
      console.log(this.Events)
    }
  }
  ngOnInit(): void {
    this.getPublicEventList();
    
   }



  

}
