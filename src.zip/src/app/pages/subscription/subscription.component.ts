import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

import { SubscriptionService } from './subscription.service';
@Component({
  selector: 'app-subscription',
  templateUrl: './subscription.component.html',
  styleUrls: ['./subscription.component.scss']
})
export class SubscriptionComponent implements OnInit {
    data:any;
    SubcriptionList:any;
  constructor(private router:Router ,private subscriptionService:SubscriptionService ) {
   }

  

  async getSubcriptionList(){
    const response:any = await this.subscriptionService.getAllSubscriptionList();
    if(response.msg=="Success"){
      this.SubcriptionList=response.data;
      console.log(response.SubcriptionList)
    }
  }
  ngOnInit(): void {
    this.getSubcriptionList()
  }

  async navigate(){
   
    const response:any = await this.subscriptionService.skipSubscription({"":""});
    if(response.msg=="Success"){
      this.router.navigate(['/home']);
    }
  }

}
