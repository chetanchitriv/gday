import { ProfileService } from './../../shared/services/data-communication-services/profile.service';
import { Component, OnInit, OnDestroy } from '@angular/core';
import { Subject, Subscription } from 'rxjs';
import { BsModalRef, BsModalService } from 'ngx-bootstrap/modal';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { RegexEnum } from '../../global/regex-enum';
import { TranslateService } from '@ngx-translate/core';
import { FormService } from '../../shared/services/form.service';
import { AuthenticationService } from '../../shared/services/auth/auth.service';
import { LocalStorageService } from '../../shared/services/local-storage.service';
import { LOCAL_STORAGE_KEYS, constants, KYC_STATUS, ROUTE_PATHS } from '../../global/constants';
import { HttpErrorHandler } from '../../shared/services/error-handler/http-error-handler.service';
import { NgxUiLoaderService } from 'ngx-ui-loader';
import { Router } from '@angular/router'; 


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit, OnDestroy {

  private response: Subject<any>;
  loginForm: FormGroup;
  subscription: Subscription;
  messageList: any = {};
  agent = constants.ROLE.AGENT;

  constructor(
    private modalService: BsModalService,
    private modalRef: BsModalRef,
    private formBuilder: FormBuilder,
    public translation: TranslateService,
    private formService: FormService,
    private authService: AuthenticationService,
    private localStorage: LocalStorageService,
    private profileService: ProfileService,
    private errorHandler: HttpErrorHandler,
    private ngxLoader: NgxUiLoaderService,
    private router:Router
  ) { }

  ngOnInit() {
    this.response = new Subject();
    this.intializingUserForm();
    this.intializingMessage();
    this.getMobileNotVerfied();
    this.getEmailNotVerfied(); 
  }

  intializingUserForm() {
    return this.loginForm = this.formBuilder.group({
      mobile: ['', [Validators.required,Validators.pattern(RegexEnum.mobile)]],
      country_code: ['', [Validators.required,Validators.pattern(RegexEnum.country_code)]],
      password: ['', Validators.required],
    });
  }

  intializingMessage() {
    this.messageList.mobile = {
      pattern: this.translation.instant('ERR_MSG_INVALID_MOBILE_NUMBER'),
      required: this.translation.instant('ERR_MSG_MOBILE_REQUIRED'),
    };

    this.messageList.password = {
      required: this.translation.instant('ERR_MSG_PASSWORD_REQUIRED'),
    };
  }

  onHide() {
    this.modalRef.hide();
  }

  onSignup() {
    const initialState = {};
  }

  onForgotPassword() {
    this.onHide();
    const initialState = {};
  }

  async onLogin() {
    
    this.formService.markFormGroupTouched(this.loginForm);
    if (this.loginForm.valid) {
      let data = this.loginForm.getRawValue();
      data["mobile"] = parseInt(data.mobile);
      this.ngxLoader.start();
      const response: any = await this.authService.login(data);
      console.log(response.data.token)
      if (response && response.data.token) {
        await this.localStorage.setDataInIndexedDB(LOCAL_STORAGE_KEYS.TOKEN,response.data.token);
     
        await this.localStorage.setDataInIndexedDB(LOCAL_STORAGE_KEYS.FULLNAME, response.data.fullName);
        await this.localStorage.setDataInIndexedDB(LOCAL_STORAGE_KEYS.IS_REFERAL_CODE, response.data.referral_code);
        await this.localStorage.setDataInIndexedDB(LOCAL_STORAGE_KEYS.EMAIL, response.data.email);
        await this.localStorage.setDataInIndexedDB(LOCAL_STORAGE_KEYS.COUNTRY_CODE, response.data.country_code);
        await this.localStorage.setDataInIndexedDB(LOCAL_STORAGE_KEYS.MOBILE, response.data.mobile);
        await this.localStorage.setDataInIndexedDB(LOCAL_STORAGE_KEYS.EMAIL, response.data.email);
        await this.localStorage.setDataInIndexedDB(LOCAL_STORAGE_KEYS.IS_VERIFIED, response.data.is_verified);
        await this.localStorage.setDataInIndexedDB(LOCAL_STORAGE_KEYS.PROFILE_IMAGE, response.data.profile_image);
        if(!response.data.subscription)
              this.router.navigate([ROUTE_PATHS.SUBSCRIPTION]);
      }else{
        this.router.navigate([ROUTE_PATHS.HOME])
      }
    }
  }

  async getMobileNotVerfied() {
    this.subscription = this.errorHandler.mobileNotverified.asObservable().subscribe(async (notVerified: any) => {
      if (notVerified) {
        const initialState = {
          mobile: this.loginForm.value.mobile,
          title: this.translation.instant('MOBILE_NUMBER_NOT_VALID_TITLE'),
          text: this.translation.instant('MOBILE_NUMBER_NOT_VALID_TEXT'),
        };
        this.modalRef.content.response.subscribe(async (shouldYes: any) => {
          if (!shouldYes) { return; }
          this.errorHandler.mobileNotverified.next(false);
        });
      }
    });
  }

  async getEmailNotVerfied() {
    this.subscription = this.errorHandler.emailNotverified.asObservable().subscribe(async (notVerified: any) => {
      if (notVerified) {
        const initialState = {
          mobile: false,
          title: this.translation.instant('EMAIL_NOT_VALID_TITLE'),
          text: this.translation.instant('EMAIL_NOT_VALID_TEXT'),
        };
        this.errorHandler.emailNotverified.next(false);
      }
    });
  }

  ngOnDestroy() {
    if (this.subscription) {
      this.subscription.unsubscribe();
    }
  }

}
