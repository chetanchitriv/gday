import { Component, OnInit } from '@angular/core';
import { Subject } from 'rxjs';
import { BsModalService, BsModalRef } from 'ngx-bootstrap/modal';
import { LoginComponent } from '../login/login.component';
import { FormBuilder, Validators, FormGroup, FormControl } from '@angular/forms';
import { TranslateService } from '@ngx-translate/core';
import { FormService } from '../../shared/services/form.service';
import { AuthenticationService } from '../../shared/services/auth/auth.service';
import { LocalStorageService } from '../../shared/services/local-storage.service';
import { RegexEnum } from '../../global/regex-enum';
import { constants, LOCAL_STORAGE_KEYS,ROUTE_PATHS } from '../../global/constants';
import { NgxUiLoaderService } from 'ngx-ui-loader';
import { Router } from '@angular/router';

@Component({
  selector: 'app-otp',
  templateUrl: './otp.component.html',
  styleUrls: ['./otp.component.scss']
})
export class OtpComponent implements OnInit {

  private response: Subject<any>;
  otpForm: FormGroup;
  messageList: any = {};
  showEmail;
  email = constants.EMAIL;
  mobileNumber = constants.MOBILE_NUMBER;
  type;
  
  


  constructor(
    private modalService: BsModalService,
    private modalRef: BsModalRef,
    private formBuilder: FormBuilder,
    public translation: TranslateService,
    private formService: FormService,
    private authService: AuthenticationService,
    private localStorage: LocalStorageService,
    private ngxLoader: NgxUiLoaderService,
    private router:Router
  ) { }

  ngOnInit() {
    this.response = new Subject();
    this.intializingOtpForm();
    this.intializingMessage();
    // this.requestOTP();
  }

  intializingOtpForm() {
    return this.otpForm = this.formBuilder.group({
      otp: ['', [Validators.required]],
     
      
    });
  }

  intializingMessage() {
    this.messageList.otp = {
      required: this.translation.instant('ERR_MSG_OTP_REQUIRED'),
    };

 
  }


  async requestOTP(){
    let mobile =  await this.localStorage.getDataFromIndexedDB(LOCAL_STORAGE_KEYS.MOBILE);
    let country_code =  await this.localStorage.getDataFromIndexedDB(LOCAL_STORAGE_KEYS.COUNTRY_CODE);

    if (mobile) {
      const response: any = await this.authService.requestOtp({ mobile:mobile ,country_code:country_code});
      if (response && response.msg) {
      }
    } else {
    

    }

  }


 
  async onOtp() {
    this.formService.markFormGroupTouched(this.otpForm);
    if (this.otpForm.valid) {
      //debugger
      this.ngxLoader.start();
    
      const data: any = this.otpForm.getRawValue();
      let mobile =  await this.localStorage.getDataFromIndexedDB(LOCAL_STORAGE_KEYS.MOBILE);
      let country_code =  await this.localStorage.getDataFromIndexedDB(LOCAL_STORAGE_KEYS.COUNTRY_CODE);
  
      if (mobile && country_code) {
        
        const response: any = await this.authService.verifyOtp({ mobile: mobile,country_code:country_code,otp:parseInt(data.otp) });
      
        if (response && response.msg) {
          
          this.router.navigate([""])
        }
      } else {
       
      }

    }
  }

 

}
